echo "right clasper open... slave" | festival --tts
python RCO.py
