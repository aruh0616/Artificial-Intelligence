echo "move backward... slave" | festival --tts
python MB.py
