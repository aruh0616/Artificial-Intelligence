import serial
import time 
print " commanding robot to Shoulder UP "
port = serial.Serial("/dev/ttyUSB0", baudrate=9600, timeout=1.0)
print " commanding robot to Left elbow up "
port.write('\x60')
time.sleep(3000 / 1000);
port.write('\x84')
time.sleep(500 / 1000);
port.write('\x84')
