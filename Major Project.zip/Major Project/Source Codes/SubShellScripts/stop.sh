echo "stop... slave" | festival --tts
python STOP.py
