echo "turn left... slave" | festival --tts
python TL.py
