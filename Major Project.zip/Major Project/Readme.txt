/*
*	The Source codes are available in SourceCodes folder:
		Code Hierarchy-
			* MainCode
			* SubShellScripts
			* Intercomm_PythonCodes

The project is based on controlling humanoids using speech (Built a Speech recognition system).
Intercommunication between two humanoids is enabled using Zigbee modules.
Humanoid was capable of detection shape using RPi camera.

It works as below,
	When a user utters a command, the command is transfered through bluetooth headset and the PocketSphinx(Speechrecognition system)
	converts the speech into corresponding text. The speech recognition system is optimized and trained with list of words stored in
	database as a .dic(dictionary) and .lm(language model) file. The converted text is given as input to the main code where it trys to map 
	the text with the available language and dictionary file. If the command matches then it calls the respective Python or Shell file accordingly.
	
	Here, there are two humanoids - 1. Master 2. Slave
		Both Master and Slave humanoids could be operated independently through Speech
		Master humanoid intercommunicate with Slave humanoid through signals and make Slave to perform required operation.

Shape detection was implemented using Cany Detection Algorithm using Image Processing on Raspberry Pi(RPi) camera.
		
	