echo "turn right... slave" | festival --tts
python TR.py
