echo "right shoulder up... slave" | festival --tts
python RSU.py
