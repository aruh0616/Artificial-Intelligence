import serial
import time 
port = serial.Serial("/dev/ttyUSB0", baudrate=9600, timeout=1.0)
print " commanding robot to Left shoulder up "
port.write('\x57')
time.sleep(4000 / 1000);
port.write('\x84')
time.sleep(500 / 1000);
port.write('\x84')
