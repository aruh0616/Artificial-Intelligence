import serial
import time 
port = serial.Serial("/dev/ttyUSB0", baudrate=9600, timeout=1.0)
print " commanding robot to Head Right "
port.write('\x54')
time.sleep(2400 / 1000);
#port.read('')
port.write('\x84')
