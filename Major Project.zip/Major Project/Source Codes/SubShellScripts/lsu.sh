echo "left shoulder up... slave" | festival --tts
python LSU.py
