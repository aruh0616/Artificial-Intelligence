import serial
import time 
port = serial.Serial("/dev/ttyUSB0", baudrate=9600, timeout=1.0)
print " commanding robot to Head Left "
port.write('\x55')
time.sleep(4000 / 1000)
port.write('\x84')

