import serial
import time 
port = serial.Serial("/dev/ttyUSB0", baudrate=9600, timeout=1.0)
port.write('\x03')
time.sleep(2400 / 1000);
port.write('\xFF')