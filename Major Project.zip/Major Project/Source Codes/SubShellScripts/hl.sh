echo "head left....    slave" | festival --tts
python HL.py
