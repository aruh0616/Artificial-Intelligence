#Artificial Intelligence : Implementation of Speech recognition system and Intercommunication between humanoids.
#Shell script for text keyword spotting and intercommunication + TTS

while [ 0 ]

do
timeout 15 ./pocketsphinx_continuous -adcdev plughw:1 -lm 0092.lm -dict 0092.dic | tee cmd.txt

#Run pocketsphinx with your language model file and dictionary file name

head -n 4 cmd.txt | tail -n 1 > cmd1.txt

cut -d " " -f 2- cmd1.txt | tee cmd2.txt

case $(tr -d ' ' <cmd2.txt) in

HELLOROBOT) echo “Hello Everyone, Have a nice day” | festivsl --tts ;;
#Here echo is a command used to implement TTS(Text to Speech) which works on Festival package installed on RPi.

RECORDAUDIO) timeout 10 arecord –D plughw:1,0 sound.wav ;;
#record audio for 10 seconds and save it as sound.wav

PLAYAUDIO) aplay sound.wav ;; #plaing the recorded audio

CAPUTREIMAGE) raspistill –o image.jpg ;; #captures the image file in .jpg format

DISPLAYIMAGE) links2 -g image.jpg ;; #display the image file named image.jpg

ROBO_HEAD_RIGHT) ./hr.sh ;; # rotates slave head towards right

ROBO_HEAD_LEFT) ./hl.sh ;;

ROBO_STOP) ./stop.sh ;;

INTRODUCE) aplay Intro.wav ;;

ROBO_RIGHT_SHOULDER_UP) ./rsu.sh ;;

ROBO_RIGHT_SHOULDER_DOWN) ./rsd.sh ;;

ROBO_RIGHT_ELBOW_UP) ./reu.sh ;;

ROBO_RIGHT_ELBOW_DOWN) ./red.sh ;;

ROBO_RIGHT_CLASPER_OPEN) ./rco.sh ;;

ROBO_RIGHT_CLASPER_CLOSE) ./rcc.sh ;;

ROBO_LEFT_SHOULDER_UP) ./lsu.sh ;;

ROBO_LEFT_SHOULDER_DOWN) ./lsd.sh ;;

ROBO_LEFT_ELBOW_UP) ./leu.sh ;;

ROBO_LEFT_ELBOW_DOWN) ./led.sh ;;

ROBO_LEFT_CLASPER_OPEN) ./lco.sh ;;

ROBO_LEFT_CLASPER_CLOSE) ./lcc.sh ;;

ROBO_MOVE_FORWARD) ./mf.sh ;;

ROBO_MOVE_BACKWARD) ./mb.sh ;;

ROBO_TURN_LEFT) ./tl.sh ;;

ROBO_TURN_RIGHT) ./tr.sh ;;

HEAD_RIGHT) python MHR.py ;; # rotates master head towards right

HEAD_LEFT) python MHL.py ;;

RIGHT_SHOULDER_UP) python MRSU.py ;;

RIGHT_SHOULDER_DOWN) python MRSD.py ;;

LEFT_SHOULDER_UP) python MLSU.py ;;

LEFT_SHOULDER_DOWN) python MLSD.py ;;

LEFT_ELBOW_UP) python MLEU.py ;;

LEFT_ELBOW_DOWN) python MLED.py ;;

RIGHT_ELBOW_UP) python MREU.py ;;

RIGHT_ELBOW_DOWN) python MRED.py ;;

RIGHT_WRIST_RIGHT) python MRWR.py ;;

RIGHT_WRIST_LEFT) python MRWL.py ;;

LEFT_WRIST_RIGHT) python MLWR.py ;;

LEFT_WRIST_LEFT) python MLWL.py ;;

RIGHT_CLASPER_OPEN) python MRCO.py ;;

RIGHT_CLASPER_CLOSE) python MRCC.py ;;

LEFT_CLASPER_OPEN) python MRCO.py ;;

LEFT_CLASPER_CLOSE) python MRCC.py ;;

MOVE_FORWARD) python MTR.py ;;

MOVE_BACKWARD) python MTL.py ;;

TURN_RIGHT) python MMF.py ;;

TURN_LEFT) python MMB.py ;;

*) ;;

esac

done