import serial
 
port = serial.Serial("/dev/ttyUSB0", baudrate=9600, timeout=1.0)
print " commanding robot to Stop " 
port.write('\x84')
