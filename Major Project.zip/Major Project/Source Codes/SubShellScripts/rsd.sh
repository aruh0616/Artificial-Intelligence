echo "right shoulder down... slave" | festival --tts
python RSD.py
