echo "left elbow down... slave" | festival --tts
python LED.py
