import serial
import time 
port = serial.Serial("/dev/ttyUSB0", baudrate=9600, timeout=1.0)
print " commanding robot to Left shoulder down "
port.write('\x58')
time.sleep(4000 / 1000);
port.write('\x84')
time.sleep(750 / 1000);
port.write('\x84')
