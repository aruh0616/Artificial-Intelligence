echo "left clasper open... slave" | festival --tts
python LCO.py
