import serial
import time 
port = serial.Serial("/dev/ttyUSB0", baudrate=9600, timeout=1.0)
print " commanding robot to Turn Right "
port.write('\x76')
time.sleep(5500 / 1000);
port.write('\x84')
time.sleep(750 / 1000);
port.write('\x84')
