echo "left shoulder down... slave" | festival --tts
python LSD.py
