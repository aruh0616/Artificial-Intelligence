echo "left elbow up... slave" | festival --tts
python LEU.py
