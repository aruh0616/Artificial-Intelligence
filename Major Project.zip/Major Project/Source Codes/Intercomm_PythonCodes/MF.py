import serial
import time 
port = serial.Serial("/dev/ttyUSB0", baudrate=9600, timeout=1.0)
print " commanding robot to Move forward "
port.write('\x73')
time.sleep(10000 / 1000);
port.write('\x84')
time.sleep(500 / 1000);
port.write('\x84')


