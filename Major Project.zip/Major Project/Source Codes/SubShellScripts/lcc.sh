echo "left clasper close... slave" | festival --tts
python LCC.py
