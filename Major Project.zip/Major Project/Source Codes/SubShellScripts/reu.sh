echo "right elbow up... slave" | festival --tts
python REU.py
