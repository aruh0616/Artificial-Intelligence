echo "move forward... slave" | festival --tts
python MF.py
