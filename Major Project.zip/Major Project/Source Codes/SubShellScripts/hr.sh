echo "head right....    slave" | festival --tts
python HR.py
