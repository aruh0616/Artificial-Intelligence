echo "right clasper close... slave" | festival --tts
python RCC.py
