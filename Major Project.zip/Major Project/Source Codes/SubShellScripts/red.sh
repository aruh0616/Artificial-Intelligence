echo "right elbow down... slave" | festival --tts
python RED.py
