import serial
 
port = serial.Serial("/dev/ttyAMA0", baudrate=9600, timeout=1.0)
port.write('\x56')
